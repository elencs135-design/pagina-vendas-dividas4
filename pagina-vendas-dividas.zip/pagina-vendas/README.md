# Livre das Dívidas até 2026

Página de vendas moderna e responsiva para o guia "Livre das Dívidas até 2026".

## 🚀 Características

- ✨ Animações suaves ao scroll
- 📱 Design totalmente responsivo
- 🎨 Paleta de cores profissional
- ⚡ Performance otimizada
- 🔍 SEO-friendly
- ♿ Acessível

## 📁 Estrutura

```
.
├── index.html      # Página principal
├── style.css       # Estilos customizados
├── script.js       # Funcionalidades interativas
└── README.md       # Este arquivo
```

## 🛠️ Como Usar Localmente

1. Clone ou baixe este repositório
2. Abra `index.html` em seu navegador
3. Pronto! A página será carregada

## 🌐 Deploy na Vercel

### Opção 1: Via GitHub (Recomendado)

1. Crie um repositório no GitHub
2. Faça upload dos arquivos
3. Vá para [vercel.com](https://vercel.com)
4. Clique em "New Project"
5. Selecione seu repositório
6. Clique em "Deploy"

### Opção 2: Via Vercel CLI

```bash
npm i -g vercel
vercel
```

## 📊 Seções da Página

1. **Hero** - Título e subtítulo principal
2. **Pain** - Imagem e pergunta provocativa
3. **Problem** - Estatísticas sobre endividamento
4. **Solution** - Apresentação da técnica
5. **Visualization** - Galeria de imagens
6. **CTA** - Chamada para ação
7. **Footer** - Rodapé

## 🎨 Cores

- Fundo principal: `#0D1B2A`
- Fundo secundário: `#1B263B`
- Destaque: `#FF9E00` e `#FFC947`
- Texto: `#E0E1DD`

## 📝 Licença

Todos os direitos reservados © 2025 Soluções Sem Dívidas

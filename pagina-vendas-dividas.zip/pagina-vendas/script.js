// Intersection Observer para animações ao scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting) {
            entry.target.style.animation = 'revealOnScroll 0.8s ease-out forwards';
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Observar todos os elementos com classe reveal-on-scroll
document.querySelectorAll('.reveal-on-scroll').forEach((element) => {
    element.style.opacity = '0';
    element.style.transform = 'translateY(30px)';
    observer.observe(element);
});

// Smooth scroll para links internos
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Adicionar classe active ao link de navegação baseado no scroll
window.addEventListener('scroll', () => {
    const sections = document.querySelectorAll('section, header');
    let current = '';

    sections.forEach((section) => {
        const sectionTop = section.offsetTop;
        if (pageYOffset >= sectionTop - 200) {
            current = section.getAttribute('id');
        }
    });
});

// Efeito de parallax simples para imagens
const imageGalleryItems = document.querySelectorAll('.image-gallery-item');

window.addEventListener('scroll', () => {
    imageGalleryItems.forEach((item) => {
        const scrollPosition = window.pageYOffset;
        const elementOffset = item.offsetTop;
        const distance = elementOffset - scrollPosition;

        if (distance > -500 && distance < window.innerHeight) {
            item.style.transform = `translateY(${distance * 0.1}px)`;
        }
    });
});

// Adicionar feedback visual ao clicar no botão CTA
const ctaButton = document.querySelector('.cta-button');
if (ctaButton) {
    ctaButton.addEventListener('click', (e) => {
        // Criar ripple effect
        const ripple = document.createElement('span');
        const rect = ctaButton.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = e.clientX - rect.left - size / 2;
        const y = e.clientY - rect.top - size / 2;

        ripple.style.width = ripple.style.height = size + 'px';
        ripple.style.left = x + 'px';
        ripple.style.top = y + 'px';
        ripple.classList.add('ripple');

        ctaButton.appendChild(ripple);

        setTimeout(() => {
            ripple.remove();
        }, 600);
    });
}

// Adicionar estilos para ripple effect dinamicamente
const style = document.createElement('style');
style.textContent = `
    .cta-button {
        position: relative;
        overflow: hidden;
    }

    .ripple {
        position: absolute;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.6);
        transform: scale(0);
        animation: ripple-animation 0.6s ease-out;
        pointer-events: none;
    }

    @keyframes ripple-animation {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Lazy loading para imagens
if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                const img = entry.target;
                if (img.dataset.src) {
                    img.src = img.dataset.src;
                    img.removeAttribute('data-src');
                }
                imageObserver.unobserve(img);
            }
        });
    });

    document.querySelectorAll('img[data-src]').forEach((img) => {
        imageObserver.observe(img);
    });
}

// Função para rastrear eventos (analytics)
function trackEvent(eventName, eventData = {}) {
    if (window.gtag) {
        gtag('event', eventName, eventData);
    }
    console.log(`Event tracked: ${eventName}`, eventData);
}

// Rastrear clique no botão CTA
if (ctaButton) {
    ctaButton.addEventListener('click', () => {
        trackEvent('cta_click', {
            button_text: 'Adquira Seu Guia e Comece 2026 Sem Dívidas!'
        });
    });
}

// Rastrear scroll até seção específica
window.addEventListener('scroll', () => {
    const purchaseSection = document.querySelector('#purchase');
    if (purchaseSection) {
        const rect = purchaseSection.getBoundingClientRect();
        if (rect.top < window.innerHeight && rect.bottom > 0) {
            if (!window.purchaseSectionViewed) {
                window.purchaseSectionViewed = true;
                trackEvent('purchase_section_viewed');
            }
        }
    }
});

// Inicializar página
document.addEventListener('DOMContentLoaded', () => {
    console.log('Página carregada com sucesso!');
    trackEvent('page_load');
});

// Detectar modo escuro do sistema
if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    document.documentElement.classList.add('dark-mode');
}

// Listener para mudanças de tema do sistema
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
    if (e.matches) {
        document.documentElement.classList.add('dark-mode');
    } else {
        document.documentElement.classList.remove('dark-mode');
    }
});
